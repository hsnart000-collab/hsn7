package com.mylife.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
// V1 placeholder: reminder rescheduling after reboot will be connected to Room in the next iteration.
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { /* TODO: reload scheduled tasks from Room */ }
}
