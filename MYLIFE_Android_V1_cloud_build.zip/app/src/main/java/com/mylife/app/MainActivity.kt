package com.mylife.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.mylife.app.data.AppDatabase
import com.mylife.app.data.TaskEntity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF17243A)
private val Cyan = Color(0xFF20C6B7)
private val Muted = Color(0xFF9EADC3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        setContent { MyLifeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun MyLifeApp() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).taskDao() }
    val tasks by dao.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var showAdd by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var reminderAt by remember { mutableStateOf<Long?>(null) }
    val dateFmt = remember { SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale.getDefault()) }
    MaterialTheme(colorScheme = darkColorScheme(primary=Cyan, background=Navy, surface=Panel)) {
        Scaffold(containerColor=Navy, floatingActionButton = {
            FloatingActionButton(onClick={showAdd=true}, containerColor=Cyan, contentColor=Navy) { Icon(Icons.Default.Add, "إضافة مهمة") }
        }) { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp), contentPadding=PaddingValues(top=24.dp,bottom=90.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                item {
                    Text("MYLIFE", color=Color.White, fontSize=30.sp, fontWeight=FontWeight.Bold)
                    Text("حياتي • خطّط يومك، واصنع تقدّمك", color=Muted, fontSize=14.sp)
                }
                item {
                    Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(22.dp), modifier=Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("ملخص اليوم", color=Muted)
                            Spacer(Modifier.height(8.dp))
                            Text("${tasks.count { !it.completed }}", color=Color.White, fontSize=38.sp, fontWeight=FontWeight.Bold)
                            Text("مهام متبقية • ${tasks.count { it.completed }} مكتملة", color=Cyan)
                        }
                    }
                }
                item { Text("مهامك", color=Color.White, fontSize=20.sp, fontWeight=FontWeight.Bold) }
                if(tasks.isEmpty()) item { Text("لا توجد مهام بعد. اضغط + لإضافة أول مهمة.", color=Muted) }
                items(tasks, key={it.id}) { task ->
                    Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                            IconButton(onClick={scope.launch { dao.update(task.copy(completed=!task.completed)) }}) {
                                Icon(Icons.Default.CheckCircle, null, tint=if(task.completed) Cyan else Muted)
                            }
                            Column(Modifier.weight(1f)) {
                                Text(task.title, color=if(task.completed) Muted else Color.White, fontWeight=FontWeight.SemiBold)
                                task.dueAt?.let { Text("⏰ ${dateFmt.format(Date(it))}", color=Cyan, fontSize=12.sp) }
                            }
                        }
                    }
                }
            }
        }
        if(showAdd) AlertDialog(
            onDismissRequest={showAdd=false},
            title={Text("مهمة جديدة")},
            text={
                Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value=title,onValueChange={title=it},label={Text("اسم المهمة")},singleLine=true)
                    OutlinedButton(onClick={
                        val now=Calendar.getInstance()
                        DatePickerDialog(context,{_,y,m,d ->
                            TimePickerDialog(context,{_,h,min ->
                                val c=Calendar.getInstance().apply { set(y,m,d,h,min,0); set(Calendar.MILLISECOND,0) }
                                reminderAt=c.timeInMillis
                            },now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true).show()
                        },now.get(Calendar.YEAR),now.get(Calendar.MONTH),now.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Icon(Icons.Default.Notifications,null); Spacer(Modifier.width(6.dp)); Text(reminderAt?.let{dateFmt.format(Date(it))} ?: "تحديد تذكير (اختياري)") }
                }
            },
            confirmButton={TextButton(onClick={
                if(title.isNotBlank()) scope.launch {
                    val id=dao.insert(TaskEntity(title=title.trim(),dueAt=reminderAt))
                    reminderAt?.let { ReminderScheduler.schedule(context,id.toInt(),title.trim(),it) }
                    title=""; reminderAt=null; showAdd=false
                }
            }){Text("حفظ")}},
            dismissButton={TextButton(onClick={showAdd=false}){Text("إلغاء")}}
        )
    }
}
