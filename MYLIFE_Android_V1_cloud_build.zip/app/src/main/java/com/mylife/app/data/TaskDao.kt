package com.mylife.app.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY completed ASC, dueAt IS NULL, dueAt ASC, createdAt DESC")
    fun observeAll(): Flow<List<TaskEntity>>
    @Insert suspend fun insert(task: TaskEntity): Long
    @Update suspend fun update(task: TaskEntity)
    @Delete suspend fun delete(task: TaskEntity)
}
